"""Simple data processing utilities for the Product Analytics Suite."""
import pandas as pd
from datetime import datetime

def load_events(path):
    df = pd.read_csv(path, parse_dates=['event_time'])
    return df

def pivot_user_features(df):
    # Aggregates basic user-level features (session length, purchase counts, last seen)
    agg = df.groupby('user_id').agg(
        sessions_count=('session_length','count'),
        avg_session_length=('session_length','mean'),
        total_purchase=('purchase_value','sum'),
        last_seen=('event_time','max'),
        feature_flag_used=('feature_flag', 'max')
    ).reset_index()
    agg['days_since_last_seen'] = (pd.Timestamp.utcnow() - agg['last_seen']).dt.days
    return agg

if __name__ == '__main__':
    import argparse, os
    p=argparse.ArgumentParser()
    p.add_argument('--in', dest='inpath', required=True)
    p.add_argument('--out', dest='outpath', required=True)
    args=p.parse_args()
    df=load_events(args.inpath)
    out=pivot_user_features(df)
    out.to_csv(args.outpath, index=False)
