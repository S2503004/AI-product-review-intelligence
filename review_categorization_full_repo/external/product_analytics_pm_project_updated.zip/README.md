# Product Analytics Suite — PM-ready AI-enabled Data Analytics Product

**Project summary:** A deployable analytics product designed for Product Managers: includes data pipeline, exploratory analysis, ML-powered churn prediction, A/B test analyzer, and an interactive dashboard (Streamlit) to drive product decisions.

## Deliverables in this repo
- Complete source code (data pipeline, model training, dashboard).
- Sample dataset and data schema.
- Documentation: architecture, setup, usage, report.
- Dockerfile and CI config for GitHub Actions (basic).
- Suggested Git commit history (see `commit_history.txt`).
- Resume-ready description and optional extensions.

## Quick start (developer)
1. Create a virtualenv and install dependencies:
   ```bash
   python -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```
2. Run the dashboard locally:
   ```bash
   streamlit run app.py
   ```
3. Train model (example):
   ```bash
   python model/train.py --data sample_data/events_sample.csv --out model/churn_model.joblib
   ```

## Notes
- This repo is intentionally modular to reflect production-style layout.
- See `architecture.md` for diagrams and `report.md` for a product-oriented deliverable.
