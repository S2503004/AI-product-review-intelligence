"""Streamlit dashboard for Product Analytics Suite."""
import streamlit as st
import pandas as pd
from model.predict import predict
import joblib, os

st.set_page_config(page_title='Product Analytics PM Dashboard', layout='wide')

st.title('Product Analytics — PM Dashboard')

st.sidebar.header('Controls')
sample_mode = st.sidebar.checkbox('Use sample data', True)

if sample_mode:
    features_csv = 'processed_features/sample_features.csv'
else:
    features_csv = st.sidebar.text_input('Path to processed features CSV', 'processed_features/sample_features.csv')

if st.sidebar.button('Load model & predict'):
    model_path = st.sidebar.text_input('Model path', 'model/churn_model.joblib')
    if not os.path.exists(model_path):
        st.error('Model not found at {}'.format(model_path))
    else:
        df = predict(model_path, features_csv)
        st.subheader('Churn predictions (top 20)')
        st.dataframe(df.sort_values('churn_probability', ascending=False).head(20))

st.markdown('## Quick insights')
st.markdown('- KPI: Daily active users, churn rate, average purchase value (mocked with sample data).')
st.markdown('## Product decisions')
st.markdown('Use this dashboard to prioritize retention experiments and feature rollouts.')
