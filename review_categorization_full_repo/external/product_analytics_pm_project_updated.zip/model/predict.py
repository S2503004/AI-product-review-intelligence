"""Predict churn for users using saved model."""
import joblib, pandas as pd

def predict(model_path, features_csv):
    model = joblib.load(model_path)
    df = pd.read_csv(features_csv)
    X = df[['sessions_count','avg_session_length','total_purchase','feature_flag_used','days_since_last_seen']].fillna(0)
    X['feature_flag_used'] = X['feature_flag_used'].astype(int)
    preds = model.predict_proba(X)[:,1]
    df['churn_probability'] = preds
    return df

if __name__ == '__main__':
    import argparse
    p=argparse.ArgumentParser()
    p.add_argument('--model', required=True)
    p.add_argument('--features', required=True)
    p.add_argument('--out', required=True)
    args=p.parse_args()
    outdf = predict(args.model, args.features)
    outdf.to_csv(args.out, index=False)
