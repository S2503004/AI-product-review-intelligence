"""Train a churn prediction model (toy example)."""
import argparse, joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

def load_features(path):
    return pd.read_csv(path)

def prepare_Xy(df):
    # For demo, define churn as days_since_last_seen > 30 or explicit churn_signal in sample events.
    df['churn_label'] = (df['days_since_last_seen'] > 30).astype(int)
    X = df[['sessions_count','avg_session_length','total_purchase','feature_flag_used','days_since_last_seen']].fillna(0)
    # cast boolean
    X['feature_flag_used'] = X['feature_flag_used'].astype(int)
    y = df['churn_label']
    return X, y

def train(path_in, path_out):
    df = load_features(path_in)
    X,y = prepare_Xy(df)
    X_train,X_test,y_train,y_test = train_test_split(X,y,test_size=0.2,random_state=42)
    clf = RandomForestClassifier(n_estimators=50, random_state=42)
    clf.fit(X_train,y_train)
    preds = clf.predict(X_test)
    print(classification_report(y_test, preds))
    joblib.dump(clf, path_out)

if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--data', required=True)
    p.add_argument('--out', required=True)
    args=p.parse_args()
    train(args.data, args.out)
