# Architecture

Components:
- Data ingestion: event logs -> raw CSV / streaming source (Kafka or S3).
- Data processing: batch job converts events to user-level features (Airflow/Cron).
- Model training: offline, retrainable with validation & metrics tracking.
- Serving: batch predictions or REST endpoint to get churn probability.
- Dashboard: Streamlit app for PMs; can be replaced by a React+Flask app for scale.
- CI/CD: GitHub Actions to run tests and linters; Docker for containerized deploy.

Minimal diagram (ASCII):

[Event source] -> [Raw events S3] -> [Batch processing] -> [Feature store] -> [Model training] -> [Model artifact registry]
                                             \-> [Dashboard (Streamlit)] <- [Prediction service]
