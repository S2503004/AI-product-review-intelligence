Product Analytics Suite — AI-enabled PM Tool
- Designed and implemented an end-to-end product analytics platform to identify at-risk users, run A/B analyses, and enable data-driven product decisions.
- Built data pipeline to aggregate event-level logs into user features, trained a churn prediction model (Random Forest), and deployed an interactive Streamlit dashboard for PMs to explore cohorts and export target lists.
- Delivered production-ready artifacts: codebase, Dockerfile, CI pipeline, and documentation. Demonstrated measurable KPIs through offline evaluation and sample dashboards.
- Tech: Python, pandas, scikit-learn, Streamlit, Docker, GitHub Actions.
